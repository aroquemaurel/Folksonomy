<?php
include('views/forms/register.php');
