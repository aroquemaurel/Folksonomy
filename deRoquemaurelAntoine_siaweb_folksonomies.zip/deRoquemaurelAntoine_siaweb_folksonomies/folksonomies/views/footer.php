</div> <!-- /container -->
<script src="style//js/bootstrap-alert.js"></script>
<script src="style//js/bootstrap-tooltip.js"></script>
<script type="text/javascript">
$(function (){
$('a').tooltip();
});
</script>
<!-- Le javascript
================================================== -->
<!-- Placed at the end of the document so the pages load faster -->
<!--<script src="style//js/bootstrap-transition.js"></script>

<script src="style//js/bootstrap-modal.js"></script>

<script src="style//js/bootstrap-dropdown.js"></script>
<script src="style//js/bootstrap-scrollspy.js"></script>
<script src="style//js/bootstrap-tab.js"></script>

<script src="style//js/bootstrap-popover.js"></script>
<script src="style//js/bootstrap-button.js"></script>

<script src="style//js/bootstrap-collapse.js"></script>
<script src="style//js/bootstrap-carousel.js"></script>
<script src="style//js/bootstrap-typeahead.js"></script>
-->
</body>
</html>
