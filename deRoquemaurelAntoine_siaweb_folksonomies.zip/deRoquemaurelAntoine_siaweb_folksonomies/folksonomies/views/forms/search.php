<div id="search">
	<form class="form-inline" method="get" action="?" >
		<div class="input-prepend input-append">
			<span class="add-on"><i class="icon-search"></i></span>
			<input id="prependedInput" style="height: 30px" type="text" class="span2" placeholder="Search" name="k" />
			<input type="submit" class="btn" value="Rechercher" />
		</div>
	</form>
</div>
